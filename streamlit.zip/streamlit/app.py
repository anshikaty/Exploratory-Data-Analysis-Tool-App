import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.figure_factory as ff
import numpy as np
from scipy import stats
from scipy.stats import skew
from autoviz.AutoViz_Class import AutoViz_Class
import matplotlib.pyplot as plt
import os
import analyse
import chatai
#Set background color
st.markdown(
     """
     <style>
     .main{
         background-color:#ADD8E6;
     }
     </style>
     """,
     unsafe_allow_html=True
 )

st.title('Detailed Exploratory Data Analysis App')

st.markdown(""" 
This app performs detailed Exploratory Data Analysis (EDA).
**Python libraries:** streamlit, pandas, plotly, numpy, scipy
**Need to contact:** [SeaportAI.com](anshikatyagi729@@gmail.com). 
""")

#Function to save dataframe to csv file
def save_dataframe(data,filename="modified_dataset.csv"):
    data.to_csv(filename,index=False)
    return filename


file_bytes = st.file_uploader("Upload a CSV file", type="csv")

if file_bytes is not None:
    data = pd.read_csv(file_bytes)

    #Add CSS to ensure the button is at the bottom of the sidebar
    st.sidebar.markdown(
        """
        <style>
        .sidebar .sidebar-content{
            display: flex;
            flex-direction:column;
            justify-content:flex-end;
        }
        </style>
        """,
        unsafe_allow_html=True
     )
    



    if st.sidebar.button('Generate EDA Report'):
        
        with open("temp_file_bytes.csv","wb") as f:
            f.write(file_bytes.getbuffer())

        st.subheader('EDA Report')
        AV= AutoViz_Class()
        EDA_report=AV.AutoViz(filename="temp_file_bytes.csv",sep=',',depVar='',dfte=data,header=0,verbose=0,
                              lowess=False,chart_format='svg', max_rows_analyzed=150000, max_cols_analyzed=30)
       
        figs=[plt.figure(n) for n in plt.get_fignums()]
        for i ,fig in enumerate(figs):
            plot_path=f"autoviz_plot_{i}.svg"
            fig.savefig(plot_path)
            st.image(plot_path)

        for i in range(len(figs)):
            os.remove(f"autoviz_plot_{i}.svg")

        os.remove("temp_file_bytes.csv")

        
    # Display the dataset
    st.subheader('Uploaded Dataset')
    st.dataframe(data.head(6))
    # Identify column types
    categorical_cols = [col for col in data.columns if data[col].dtype == 'object']
    numerical_cols = [col for col in data.columns if data[col].dtype in ['int64', 'float64']]
    #shape of data
    rows,columns=data.shape

    st.write(f"Your dataset has {rows} rows and {columns} columns")
    st.subheader("Chat with Your AI Assistant ")

    
    if 'chat_history' not in st.session_state:
        st.session_state['chat_history']=[]

    user_input = st.text_input("Chat with AI",key="input")
    submit=st.button("Submit your query")
    if submit and input:
        result=chatai.assistant(user_input)
        st.session_state['chat_history'].append(("You", user_input))
        st.subheader("The Response is")
        st.write(result)
        st.session_state['chat_history'].append(("AI", result))
        st.subheader("Chat History")
        
        for role,text in st.session_state['chat_history']:
            st.write(f"{role}: {text}")

        
        


    type = st.sidebar.selectbox('What do you want to perform', ['Data Overview', 'Analysis'])
    if type == 'Data Overview':
        
        #show basic information
        st.subheader('Basic Data Overview')

        if st.checkbox('Show shape'):
            rows,cols=data.shape
            st.write(f" The dataset has {rows} rows and {cols} columns")

        if st.checkbox('Show columns'):
            st.write(data.columns.tolist())

        if st.checkbox('Show summary statistics'):
            st.write(data.describe())

    
        if st.checkbox('Show missing values'):
            st.write(data.isnull().sum())
            n=data.isnull().sum().sum()
            st.write(f"The total missing values in your dataset is {n}")
    
   
        if st.checkbox('Show duplicate rows'):
            st.write('Number of duplicate rows:')
            st.write(data.duplicated().sum())

        if st.checkbox('Show data types'):
            st.write(data.dtypes)
        #check unusual characters
        if st.checkbox('Check for unusual characters in column names'):
            unusual_chars = ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '+', '=', '/', '\\', '|', '{', '}', '[', ']', ':', ';', '"', "'", '<', '>', ',', '?', '`', '~']
            columns_with_unusual_chars = [col for col in data.columns if any(char in col for char in unusual_chars)]
            if columns_with_unusual_chars:
                st.write('Columns with unusual characters:', columns_with_unusual_chars)
            else:
                st.write('No unusual characters found in column names.')
        #check for negative value
        if st.checkbox('Show negative values in numeric columns'):
            numeric_columns = data.select_dtypes(include=['float64', 'int64']).columns
            negative_values = data[numeric_columns].apply(lambda x: (x < 0).sum())
            st.write(negative_values)
            st.write('Columns with negative values with total:')
            st.write(negative_values[negative_values > 0])
        #Outlier detection
        st.subheader('Outlier Detection')
        if st.checkbox('Show boxplots for outlier detection'):
            numeric_columns=data.select_dtypes(include=['float64','int64']).columns
            selected_column=st.selectbox('Select column for boxplot',numeric_columns)

            if selected_column:
                fig=px.box(data,y=selected_column,points="all")
                st.plotly_chart(fig)
        # Skewness Check
        st.subheader('Skewness Check')
        if st.checkbox('Show skewness of numeric columns'):
            numeric_columns = data.select_dtypes(include=['float64', 'int64']).columns
            skewness_values = data[numeric_columns].apply(lambda x: skew(x.dropna()))
            st.write(skewness_values)
            fig = px.bar(skewness_values, title='Skewness of Numeric Columns')
            st.plotly_chart(fig)

        # Fill Missing Values and save filled dataset
        st.subheader('Fill Missing Values')
        missing_cols = [col for col in data.columns if data[col].isnull().sum() > 0]
        if missing_cols:
            if st.checkbox('Fill missing values in a column'):
                fill_column = st.selectbox('Select column to fill missing values', missing_cols)
                # Determine fill options based on column type
                if data[fill_column].dtype in ['int64', 'float64']:
                    fill_method = st.selectbox('Select method to fill missing values in numerical column', ['Mean', 'Median'])
            
                    if fill_method == 'Mean':
                        data[fill_column].fillna(data[fill_column].mean(), inplace=True)
                    elif fill_method == 'Median':
                        data[fill_column].fillna(data[fill_column].median(), inplace=True)

                elif data[fill_column].dtype == 'object':
                    fill_method = st.selectbox('Select method to fill missing values in categorical column', ['Mode', 'Unknown'])
            
                    if fill_method == 'Mode':
                        data[fill_column].fillna(data[fill_column].mode()[0], inplace=True)
                    elif fill_method == 'Unknown':
                        data[fill_column].fillna('Unknown', inplace=True)
        
                st.write(data[fill_column].isnull().sum())  # Verify if missing values are filled
                st.write(data.head())    
        
                # Save modified dataset
                st.write("Do you want to save as csv file after filling missing values in your dataset.")
                if st.button('Save your dataset as CSV file'):
                    filename=save_dataframe(data)
                    st.write(f'saved your dataset as {filename}')
        else:
            st.write("No columns have missing values.")

          #Load the save dataset
          #saved_data=pd.read_csv(filename)
           
    elif type=="Analysis":
        # Sidebar for graphical and statistical analysis
        analysis_type = st.sidebar.selectbox('Select Analysis Type', ['Graphical Analysis', 'Statistical Analysis'])

        if analysis_type == 'Graphical Analysis':
            st.header('Graphical Analysis')
            # Univariate Analysis
            st.sidebar.subheader('Univariate Analysis')

            column = st.sidebar.selectbox('Select a column for univariate analysis', data.columns)
            if column:
                st.subheader(f'Univariate Analysis for {column}')
                plot_type = st.sidebar.radio('Select plot type', ('Histogram', 'Boxplot', 'Bar Chart', 'Pie Chart'))

                if plot_type == 'Histogram':
                    fig = analyse.generate_histogram(data, column)
                    st.plotly_chart(fig)
                elif plot_type == 'Boxplot':
                    fig = analyse.generate_boxplot(data, column)
                    st.plotly_chart(fig)
                elif plot_type == 'Bar Chart':
                    fig = analyse.generate_bar_chart(data, column)
                    st.plotly_chart(fig)

                elif plot_type == 'Pie Chart':
                    fig = analyse.generate_pie_chart(data, column)
                    if fig:
                        st.plotly_chart(fig)
                    else:
                        st.write("Too many unique values for a pie chart")
            # Bivariate Analysis
            st.sidebar.subheader('Bivariate Analysis')
            x_column = st.sidebar.selectbox('Select X-axis column', data.columns)
            y_column = st.sidebar.selectbox('Select Y-axis column', data.columns)
            if x_column != y_column:
                st.subheader(f'Bivariate Analysis for {x_column} and {y_column}')
                plot_type = st.sidebar.radio('Select plot type', ('Stacked Bar Chart', 'Line Chart', 'Scatter Plot'))
                if plot_type == 'Stacked Bar Chart':
                    fig = analyse.generate_stack_bar_chart(data, x_column, y_column)
                    st.plotly_chart(fig)

                elif plot_type == 'Line Chart':
                    fig = analyse.generate_line_chart(data, x_column, y_column)
                    st.plotly_chart(fig)

                elif plot_type == 'Scatter Plot':
                    fig = analyse.generate_scatter_plot(data, x_column, y_column)
                    st.plotly_chart(fig)
            # Multivariate Analysis
            st.sidebar.subheader('Multivariate Analysis')
            multivariate_plot_type = st.sidebar.radio('Select plot type', ('Correlation Matrix', 'Heatmap'))
            if multivariate_plot_type == 'Correlation Matrix':
                st.subheader('Correlation Matrix')
                fig = analyse.generate_correlation_matrix(data)
                st.plotly_chart(fig)

            elif multivariate_plot_type == 'Heatmap':
                st.subheader('Heatmap')
                fig = analyse.generate_heatmap(data)
                st.plotly_chart(fig)

        elif analysis_type == 'Statistical Analysis':
            st.header('Statistical Analysis')
            # Descriptive statistics
            st.subheader('Descriptive Statistics')
            st.write(data.describe(include='all'))
            # Inferential statistics
            st.subheader('Inferential Statistics')
            #T-test for numerical variables
            st.subheader('T-test')
            if len(numerical_cols) >= 2:
                num_col1 = st.selectbox('Select first numerical variable for t-test', numerical_cols, key='ttest1')
                num_col2 = st.selectbox('Select second numerical variable for t-test', numerical_cols, key='ttest2')
                if num_col1 != num_col2:
                    t_stat, p_val = stats.ttest_ind(data[num_col1].dropna(), data[num_col2].dropna())
                    st.write(f"T-test between {num_col1} and {num_col2}:")
                    st.write(f"T-statistic: {t_stat}, P-value: {p_val}")
                else:
                    st.write("Please select two different numerical variables for the t-test.")
             #F test for numerical variables
            st.subheader('F-test')
            if len(numerical_cols) >= 2:
                num_col1 = st.selectbox('Select first numerical variable for F-test', numerical_cols, key='ftest1')
                num_col2 = st.selectbox('Select second numerical variable for F-test', numerical_cols, key='ftest2')
                if num_col1 != num_col2:
                    var1 = data[num_col1].dropna().var()
                    var2 = data[num_col2].dropna().var()
                    f_stat = var1 / var2
                    dfn = len(data[num_col1].dropna()) - 1
                    dfd = len(data[num_col2].dropna()) - 1
                    p_val = 1 - stats.f.cdf(f_stat, dfn, dfd)
        
                    st.write(f"F-test between {num_col1} and {num_col2}:")
                    st.write(f"F-statistic: {f_stat}, P-value: {p_val}")
                else:
                    st.write("Please select two different numerical variables for the F-test.")
            # Chi-square test for categorical variables
            st.subheader('Chi-squared test')
            if len(categorical_cols) >= 2:
                cat_col1 = st.selectbox('Select first categorical variable for Chi-square test', categorical_cols, key='chi2_1')
                cat_col2 = st.selectbox('Select second categorical variable for Chi-square test', categorical_cols, key='chi2_2')
                if cat_col1 != cat_col2:
                    contingency_table = pd.crosstab(data[cat_col1], data[cat_col2])
                    chi2, p, dof, expected = stats.chi2_contingency(contingency_table)
                    st.write(f"Chi-square test between {cat_col1} and {cat_col2}:")
                    st.write(f"Chi2 statistic: {chi2}, P-value: {p}, Degrees of freedom: {dof}")
                    st.write("Expected frequencies:")
                    st.write(expected)
                else:
                    st.write("Please select two different categorical variables for the Chi-square test.")
             #Spiro wilk test for normality check
            st.subheader('Shapiro-Wilk test')
            if len(numerical_cols) >= 1:
                num_col = st.selectbox('Select a numerical variable for Shapiro-Wilk test', numerical_cols, key='shapirowilk')
                shapiro_stat, p_val = stats.shapiro(data[num_col].dropna())
    
                st.write(f"Shapiro-Wilk test for {num_col}:")
                st.write(f"Shapiro-Wilk statistic: {shapiro_stat}, P-value: {p_val}")
       

