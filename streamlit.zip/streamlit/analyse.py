
import plotly.express as px
# Function to generate histogram
def generate_histogram(data, column):
    fig = px.histogram(data, x=column, marginal="box", nbins=30)
    return fig

# Function to generate boxplot
def generate_boxplot(data, column):
    fig = px.box(data, y=column)
    return fig
    
# Function to generate bar chart
def generate_bar_chart(data, column):
    fig = px.bar(data, x=column)
    return fig

# Function to generate pie chart
def generate_pie_chart(data, column):
    if data[column].nunique() <= 10:  # Ensuring the column has a reasonable number of unique values
        fig = px.pie(data, names=column)
        return fig
    else:
        return None
    
#Function to generate stack bar chart
def generate_stack_bar_chart(data, x_column, y_column):
    fig = px.bar(data, x=x_column, y=y_column, color=y_column, barmode='stack')
    return fig

# Function to generate line chart
def generate_line_chart(data, x_column, y_column):
    fig = px.line(data, x=x_column, y=y_column)
    return fig

# Function to generate scatter plot
def generate_scatter_plot(data, x_column, y_column):
    fig = px.scatter(data, x=x_column, y=y_column)
    return fig

# Function to generate correlation matrix
def generate_correlation_matrix(df):
    numeric_df = df.select_dtypes(include=['float64', 'int64'])
    correlation_matrix = numeric_df.corr()
    fig = px.imshow(correlation_matrix, text_auto=True, aspect="auto")
    return fig

# Function to generate heatmap
def generate_heatmap(df):
    fig = px.imshow(df, text_auto=True, aspect="auto")
    return fig

        