import os
import streamlit as st
import google.generativeai as genai
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import SystemMessage, HumanMessage , AIMessage


# Set up Gemini API key
#genai.configure(api_key="AIzaSyAI9404GT0nuZkWgQER4GhZUNS22gfrEsI")
os.environ["GOOGLE_API_KEY"] = "AIzaSyAI9404GT0nuZkWgQER4GhZUNS22gfrEsI"
 

# Initialize Gemini Chat Model
model = ChatGoogleGenerativeAI(model="gemini-1.5-pro", temperature=0.7)

def assistant(user_input):
    result = model.invoke(user_input)
    return result.content
